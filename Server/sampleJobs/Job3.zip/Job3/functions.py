# Functions.py
def cube(n):
	return n**3