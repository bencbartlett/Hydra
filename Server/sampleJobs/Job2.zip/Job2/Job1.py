from CFQueue import CFQueue 

print "starting"

q = CFQueue(ordered=True)
for i in range(100):
	q.put("square", args=(i,))

print "processing"
results = q.process() 
print results 

with open("results.txt", "w") as f:
	f.write(str(results))
print "finished"
