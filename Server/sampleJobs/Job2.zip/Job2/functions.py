# Functions.py
def square(n):
	return n**2